#!/usr/bin/env bash
export SteamClientLaunch=1
chmod a+x ./start-tModLoader.sh
./start-tModLoader.sh